//
//  ViewController.swift
//  ColorDrops
//
//  Created by Ahmadreza on 3/3/22.
//

import UIKit

class ViewController: UIViewController {
    
    let cubeSize = 50
    let numberOfBottomButtons = 10
    var selectedButtonIndex = 1
    var buttonsColors = [UIColor]()
    var viewsForUndo = [UILabel]()
    var viewsForRedo = [UILabel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
}

// MARK: - Setup Functions
extension ViewController {
    
    func setupView() {
        
        setupNavigationBar()
        addTabBar()
        addGestureRecoginzer()
    }
    
    func setupNavigationBar() {
        let undoButton = UIBarButtonItem(title: "Undo", style: .plain, target: self, action: #selector(undoAction))
        let redoButton = UIBarButtonItem(title: "Redo", style: .plain, target: self, action: #selector(redoAction))
        navigationItem.rightBarButtonItems = [undoButton, redoButton]
    }
    
    func addGestureRecoginzer() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapAction(gesture:)))
        view.addGestureRecognizer(tap)
    }
    
    func addTabBar() {
        let width = UIScreen.main.bounds.width / CGFloat(numberOfBottomButtons)
        let height = width * 0.7
        for i in 0..<numberOfBottomButtons {
            let position = CGPoint(x: CGFloat(i) * width, y: UIScreen.main.bounds.height - height)
            let size = CGSize(width: width, height: height)
            let button = UIButton(frame: CGRect(origin: position, size: size))
            let color = UIColor(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1.0)
            button.backgroundColor = color
            buttonsColors.append(color)
            button.tag = i
            button.addTarget(self, action: #selector(bottomButtonsAction(sender:)), for: .touchUpInside)
            view.addSubview(button)
        }
        updateButtonsTitle()
    }
    
    func updateButtonsTitle() {
        if let buttons = view.subviews.filter({$0.isKind(of: UIButton.self)}) as? [UIButton] {
            buttons.forEach({$0.setTitle(" ", for: .normal)})
            if let button = buttons.filter({$0.tag == selectedButtonIndex}).first {
                button.setTitle("✅", for: .normal)
            }
        }
    }
}

// MARK: - Action Functions
extension ViewController {
    
    @objc func undoAction() {
        guard let last = viewsForUndo.last else { return }
        for v in view.subviews {
            if v == last {
                viewsForRedo.append(v as! UILabel)
                v.removeFromSuperview()
            }
        }
        viewsForUndo = viewsForUndo.dropLast()
    }
    
    @objc func redoAction() {
        if let v = viewsForRedo.last {
            viewsForUndo.append(v)
            view.addSubview(v)
            viewsForRedo = viewsForRedo.dropLast()
        }
    }
    
    @objc func bottomButtonsAction(sender: UIButton) {
        selectedButtonIndex = sender.tag
        updateButtonsTitle()
    }
    
    @objc func tapAction(gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: view)
        addView(at: location)
    }
    
    func addView(at location: CGPoint) {
        viewsForRedo = []
        let size = CGSize(width: cubeSize, height: cubeSize)
        let position = CGPoint(x: Int(location.x) - (cubeSize / 2), y: Int(location.y) - (cubeSize / 2))
        let label = UILabel(frame: CGRect(origin: position, size: size))
        label.textAlignment = .center
        label.textColor = .white
        let color = buttonsColors[selectedButtonIndex]
        label.backgroundColor = color
        label.text = view.subviews.filter({$0.backgroundColor == color}).count.description
        view.addSubview(label)
        viewsForUndo.append(label)
    }
}
